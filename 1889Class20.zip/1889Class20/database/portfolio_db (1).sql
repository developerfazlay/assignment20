-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 30, 2022 at 06:17 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portfolio_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sub_title` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `active_status` tinyint(2) NOT NULL DEFAULT 1 COMMENT '0=InActive, 1=Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `title`, `sub_title`, `details`, `image`, `active_status`) VALUES
(1, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', 'banner1.jpg', 0),
(2, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', 'banner2.jpg', 0),
(3, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', ' Class mark empty.png', 0),
(4, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', ' ', 0),
(5, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', ' ', 0),
(6, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', ' ', 0),
(7, 'Md. Fazlay Rabbi', 'its a  updated subtitle dhadha', 'This is details updated dgha', '', 0),
(8, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', '', 0),
(9, 'Md. Fazlay Rabbi', 'Subtitle', 'This is details', '', 0),
(10, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', ' ', 0),
(11, 'Md. Fazlay Rabbi', 'its a  updated ', 'details updated ', '1656424001primary.png', 0),
(12, 'New Banner', 'banner subtitle', 'banner details updated', 'Coupon.png', 0),
(13, 'New tittle', 'new subtitle', 'new details', ' bl.png', 0),
(14, '', '', '', ' Class mark empty.png', 0),
(15, '', '', '', ' Class mark empty.png', 0),
(16, '', '', '', ' Class mark empty.png', 0),
(17, '', '', '', ' Class mark empty.png', 0),
(18, 'Fa', 'sdf', 'sdfsad', ' 1656176651282158647_729427051724819_3732444365673844319_n.png', 0),
(19, 'Fazlay Rabbi', 'subtilte', 'details here', ' 1656177235Coupon.png', 0),
(20, 'Fazlay', 'this is a sub title', 'details', ' 1656177389dhadha gonit.png', 0),
(21, 'Title here', 'sub title', 'details ad', '1656424431', 0),
(22, 'Title here', 'This is subtitle', 'details here', '1656429299Coupon.png', 0),
(23, 'New banner', 'subt tile ', 'details', '1656429084Class 6.png', 0),
(24, 'New title ', 'new subtilte', 'new details', '1656429561Flood.png', 1),
(25, 'Another title ', 'another subtitle', 'another details', '1656429851bl.png', 1),
(26, 'This is a title ', 'This is a subtitle of Morium ', 'details here', '1656604152bl.png', 1),
(27, 'This is new title ', 'new subtitle', 'new details', '1656514231', 0),
(28, 'This is a title', 'this is a subtitle', 'details heere', '1656603739Class mark empty.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `active_status` tinyint(2) NOT NULL DEFAULT 1 COMMENT '1=Active and 0=Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `active_status`) VALUES
(1, 'Web development', 0),
(2, 'Wordpress Development', 1),
(3, 'Wordpress Development Pro', 0),
(4, 'Graphics Design', 1),
(5, 'Android Develop', 0),
(6, 'Android Developement', 1),
(7, 'Theme Development', 1);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `project_link` varchar(255) DEFAULT NULL,
  `project_image` varchar(100) NOT NULL,
  `active_status` tinyint(2) NOT NULL DEFAULT 1 COMMENT '1=Active and 0=Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `category_id`, `project_name`, `project_link`, `project_image`, `active_status`) VALUES
(1, 2, 'new project', '#', '1656604703Class mark empty.png', 1),
(2, 4, 'Graphics project ', 'this is a link', '1656604540288357324_579814856815634_2160436633617365561_n.jpg', 1),
(3, 5, 'New project', 'sdf', '1656605267Class mark empty.png', 1),
(4, 15, 'test project', 'test link', '1656605326group by.png', 1),
(5, 2, 'New project', 'this is a link', '1656605640bl.png', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
