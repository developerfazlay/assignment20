-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2022 at 08:58 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portfolio_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sub_title` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `active_status` tinyint(2) NOT NULL DEFAULT 1 COMMENT '0=InActive, 1=Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `title`, `sub_title`, `details`, `image`, `active_status`) VALUES
(1, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', 'banner1.jpg', 1),
(2, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', 'banner2.jpg', 1),
(3, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', ' Class mark empty.png', 0),
(4, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', ' ', 0),
(5, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', ' ', 0),
(6, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', ' ', 0),
(7, 'Md. Fazlay Rabbi', 'its a  updated subtitle dhadha', 'This is details updated dgha', '', 0),
(8, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', '', 1),
(9, 'Md. Fazlay Rabbi', 'Subtitle', 'This is details', '', 1),
(10, 'Md. Fazlay Rabbi    dsfsd', 'its a  updated subtitle', 'This is details updated', ' ', 0),
(11, 'Md. Fazlay Rabbi', 'its a  updated ', 'details updated', '', 1),
(12, 'New Banner', 'banner subtitle', 'banner details updated', 'Coupon.png', 0),
(13, 'New tittle', 'new subtitle', 'new details', ' bl.png', 0),
(14, '', '', '', ' Class mark empty.png', 0),
(15, '', '', '', ' Class mark empty.png', 0),
(16, '', '', '', ' Class mark empty.png', 0),
(17, '', '', '', ' Class mark empty.png', 0),
(18, 'Fa', 'sdf', 'sdfsad', ' 1656176651282158647_729427051724819_3732444365673844319_n.png', 1),
(19, 'Fazlay Rabbi', 'subtilte', 'details here', ' 1656177235Coupon.png', 1),
(20, 'Fazlay', 'this is a sub title', 'details', ' 1656177389dhadha gonit.png', 1),
(21, 'Title here', 'sub title', 'details', ' 1656177559primary.png', 1),
(22, 'new tilte from laptop', 'subtille', 'details', ' 1656262497kausar_ru.jpg', 1),
(23, 'dsaf', 'sdfsd', 'sdfsdfasd', ' 1656263128kawsar.jpg', 1),
(24, 'New Title ', 'new subtitle', 'details', ' 1656269868kawsar-hamid.jpg', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
